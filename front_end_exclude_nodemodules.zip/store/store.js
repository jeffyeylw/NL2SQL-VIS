import { createStore } from 'vuex'

export default createStore({
  state: {
    outputParams: null,
  },
  mutations: {
    setOutputParams(state, outputParams) {
      state.outputParams = outputParams;
    },
  },
})