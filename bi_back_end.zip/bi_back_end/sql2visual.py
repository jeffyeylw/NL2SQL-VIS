import pandas as pd
import json
import plotly.express as px
import sqlite3
from collections import Counter

# sql = "SELECT count(account_id),frequency FROM account GROUP BY frequency;"  # 由模型生成的sql查询语句
# target_db = '/Users/frankye/Desktop/BI_Project/financial/financial.sqlite'  # 目标查询数据库
# print(sql, target_db, sep='\n')

# # outputcsv_filepath = "/Users/frankye/Desktop/BI_Project/demo/test/AutoVisual_Results/test1.csv"  # 存放sql查询出的数据的.csv路径
# json_outputpath = "/Users/frankye/Desktop/BI_Project/demo/test/AutoVisual_Results/test1.json"  # 存放绘图数据的.json文件
# img_outputpath = "/Users/frankye/Desktop/BI_Project/demo/test/AutoVisual_Results/test1"  # 存放数据可视化结果图片的文件夹

'''
修改上述五个变量sql、target_db、outputcsv_filepath、json_outputpath、img_outputpath，然后运行这个python程序即可得到结果。

sql2visual.py文件会输出三个文件（对应上述三个路径）：sql查询出的数据的.csv、绘图数据的.json文件、 数据可视化结果图片。
如果只需要json文件，那么可以注释掉生成.csv文件代码和绘图代码（# 生成.csv文件代码 # 绘图代码）。

sql2visual.py文件由两部分组成：
1. sql2data()函数负责通过sql的目标数据库将数据查询出来。
2. Data2Visual()类根据第一步查询出的数据结果生成可视化结果
'''

def sql2data(sql, target_db):
    conn = sqlite3.connect(target_db)
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        rows = cursor.fetchall()
        column_names = [description[0] for description in cursor.description]
        print('SQL query succeeded.')
    except sqlite3.OperationalError:
        print('SQL query failed.')
        return None, None, None

    column_types = []
    for item in rows[0]:
        if type(item).__name__ == 'int' or type(item).__name__ == 'float':
            column_types.append('numeric')
        else:
            column_types.append('categorical')
    # print(rows, column_names, column_types, sep='\n')
    return rows, column_names, column_types


class Data2Visual():
    def __init__(self, img_outputpath, json_outputpath):
        self.column1_rule = {'categorical0': ['histogram'],
                            'categorical1': ['pie']}
        self.column2_rule = {'categorical0': ['scatter', 'line'],
                            'categorical1': ['bar', 'pie'],
                            'categorical2': []}
        self.column3_rule = {'categorical0': [],
                            'categorical1': ['scatter', 'line'],
                            'categorical2': ['bar'],
                            'categorical3': ['scatter']}
        self.column4_rule = {}
        self.rules = {'column1': self.column1_rule,
                    'column2': self.column2_rule,
                    'column3': self.column3_rule,
                    'column4': self.column4_rule}
        self.img_outputpath = img_outputpath
        self.json_outputpath = json_outputpath
    def load_data(self, rows, column_names, column_types):
        self.df = pd.DataFrame(rows, columns=column_names)
        self.column_types = column_types
        self.df.dropna(inplace=True)

    def scatter_plot(self, json_list, plot_id):
        print("Starting scatter plot generation...")
        
        plot_type_id = 0
        numeric_indices = [i for i, value in enumerate(self.column_types) if value == 'numeric']
        categorical_indices = [i for i, value in enumerate(self.column_types) if value == 'categorical']
        
        print("Numeric Indices:", numeric_indices)
        print("Categorical Indices:", categorical_indices)
        
        # Handle the scenario of two categorical columns
        if len(categorical_indices) == 2:
            x_index = categorical_indices[0]
            y_index = categorical_indices[1]
            
            x = self.df.iloc[:, x_index]
            y = self.df.iloc[:, y_index]
            xaxis_title = self.df.columns[x_index]
            yaxis_title = self.df.columns[y_index]
            
            df = pd.DataFrame({f'{xaxis_title}': x, f'{yaxis_title}': y})
            df_dict = df.to_dict(orient='list')
            df_dict['plot_type'] = 'scatter'
            df_dict['plot_type_id'] = plot_type_id
            df_dict['plot_id'] = plot_id
            json_list.append(df_dict)
            plot_type_id += 1
            plot_id += 1
        
        else:
            # Continue with the original logic for numeric columns
            for x_index in numeric_indices:
                remaining_numeric_indices = numeric_indices.copy()
                remaining_numeric_indices.remove(x_index)
                
                for y_index in remaining_numeric_indices:
                    x = self.df.iloc[:, x_index]
                    y = self.df.iloc[:, y_index]
                    xaxis_title = self.df.columns[x_index]
                    yaxis_title = self.df.columns[y_index]
                    
                    df = pd.DataFrame({f'{xaxis_title}': x, f'{yaxis_title}': y})
                    df_dict = df.to_dict(orient='list')
                    df_dict['plot_type'] = 'scatter'
                    df_dict['plot_type_id'] = plot_type_id
                    df_dict['plot_id'] = plot_id
                    json_list.append(df_dict)
                    plot_type_id += 1
                    plot_id += 1
        
        return json_list, plot_id

    def bar_chart(self, json_list, plot_id):
        plot_type_id = 0
        numeric_indices = [i for i, value in enumerate(self.column_types) if value == 'numeric']
        categorical_indices = [i for i, value in enumerate(self.column_types) if value == 'categorical']
        for y_index in numeric_indices:
            for x_index in categorical_indices:
                remaining_categorical_indices = categorical_indices.copy()
                remaining_categorical_indices.remove(x_index)
                if remaining_categorical_indices == []:  # 针对于查询数据中只有两列的情况
                    x = self.df.iloc[:, x_index]
                    y = self.df.iloc[:, y_index]
                    xaxis_title = self.df.columns[x_index]
                    yaxis_title = self.df.columns[y_index]
                    df = pd.DataFrame({f'{xaxis_title}': x, f'{yaxis_title}': y})
                    df_dict = df.to_dict(orient='list')
                    df_dict['plot_type'] = 'bar'
                    df_dict['plot_type_id'] = plot_type_id
                    df_dict['plot_id'] = plot_id
                    json_list.append(df_dict)
                    plot_type_id += 1
                    plot_id += 1

                else:  # 针对查询数据中大于两列的情况
                    for class_index in remaining_categorical_indices:
                        x = self.df.iloc[:, x_index]
                        y = self.df.iloc[:, y_index]
                        grouped_class = self.df.iloc[:, class_index]
                        xaxis_title = self.df.columns[x_index]
                        yaxis_title = self.df.columns[y_index]
                        grouped_title = self.df.columns[:, class_index]
                        df = pd.DataFrame({f'{xaxis_title}': x, f'{yaxis_title}': y, f'{grouped_title}': grouped_class})
                        df_dict = df.to_dict(orient='list')
                        df_dict['plot_type'] = 'bar'
                        df_dict['plot_type_id'] = plot_type_id
                        df_dict['plot_id'] = plot_id
                        json_list.append(df_dict)

                        plot_type_id += 1
                        plot_id += 1
        return json_list, plot_id

    def pie_chart(self, json_list, plot_id):
        plot_type_id = 0
        if self.df.shape[1] == 1:  # 针对查询数据中仅有一列的情况
            x = Counter(self.df.iloc[:, 0]).keys()
            y = Counter(self.df.iloc[:, 0]).values()
            xaxis_title = self.df.columns[0]
            yaxis_title = 'Count'
            df = pd.DataFrame({f'{xaxis_title}': x, yaxis_title: y})
            df_dict = df.to_dict(orient='list')
            df_dict['plot_type'] = 'pie'
            df_dict['plot_type_id'] = plot_type_id
            df_dict['plot_id'] = plot_id
            json_list.append(df_dict)

            plot_type_id += 1
            plot_id += 1
        elif self.df.shape[1] == 2:  # 针对查询数据中有两列的情况
            numeric_indices = [i for i, value in enumerate(self.column_types) if value == 'numeric']
            categorical_indices = [i for i, value in enumerate(self.column_types) if value == 'categorical']
            x_index, y_index = categorical_indices[0], numeric_indices[0]
            x = self.df.iloc[:, x_index]
            y = self.df.iloc[:, y_index]
            xaxis_title = self.df.columns[x_index]
            yaxis_title = self.df.columns[y_index]
            df = pd.DataFrame({f'{xaxis_title}': x, f'{yaxis_title}': y})
            df_dict = df.to_dict(orient='list')
            df_dict['plot_type'] = 'pie'
            df_dict['plot_type_id'] = plot_type_id
            df_dict['plot_id'] = plot_id
            json_list.append(df_dict)
            plot_type_id += 1
            plot_id += 1
        return json_list, plot_id
    def line_chart(self, json_list, plot_id):
        plot_type_id = 0
        numeric_indices = [i for i, value in enumerate(self.column_types) if value == 'numeric']
        categorical_indices = [i for i, value in enumerate(self.column_types) if value == 'categorical']
        
        for y_index in numeric_indices:
            for x_index in categorical_indices:
                remaining_categorical_indices = categorical_indices.copy()
                remaining_categorical_indices.remove(x_index)
                
                if remaining_categorical_indices == []:  
                    x = self.df.iloc[:, x_index]
                    y = self.df.iloc[:, y_index]
                    xaxis_title = self.df.columns[x_index]
                    yaxis_title = self.df.columns[y_index]
                    df = pd.DataFrame({f'{xaxis_title}': x, f'{yaxis_title}': y})
                    df_dict = df.to_dict(orient='list')
                    df_dict['plot_type'] = 'line'
                    df_dict['plot_type_id'] = plot_type_id
                    df_dict['plot_id'] = plot_id
                    json_list.append(df_dict)
                    plot_type_id += 1
                    plot_id += 1

                else:  
                    for class_index in remaining_categorical_indices:
                        x = self.df.iloc[:, x_index]
                        y = self.df.iloc[:, y_index]
                        grouped_class = self.df.iloc[:, class_index]
                        xaxis_title = self.df.columns[x_index]
                        yaxis_title = self.df.columns[y_index]
                        grouped_title = self.df.columns[class_index]
                        df = pd.DataFrame({f'{xaxis_title}': x, f'{yaxis_title}': y, f'{grouped_title}': grouped_class})
                        df_dict = df.to_dict(orient='list')
                        df_dict['plot_type'] = 'line'
                        df_dict['plot_type_id'] = plot_type_id
                        df_dict['plot_id'] = plot_id
                        json_list.append(df_dict)

                        plot_type_id += 1
                        plot_id += 1
        return json_list, plot_id
    # def histogram(self, json_list, plot_id):
    #     plot_type_id = 0
    #     y = self.df.iloc[:, 0]
    #     yaxis_title = self.df.columns[0]
    #     df = pd.DataFrame({f'{yaxis_title}': y})
    #     df_dict = df.to_dict(orient='list')
    #     df_dict['plot_type'] = 'bar'
    #     df_dict['plot_type_id'] = plot_type_id
    #     df_dict['plot_id'] = plot_id
    #     json_list.append(df_dict)

    #     plot_type_id += 1
    #     plot_id += 1
    #     return json_list, plot_id

    def plot(self):
        type_count = Counter(self.column_types)
                
        # 计算每个分类列的唯一值数量
        categorical_value_counts = [len(self.df[col].unique()) for col in self.df.columns if self.column_types[self.df.columns.get_loc(col)] == 'categorical']

        # 检查是否有两个分类列的唯一值数量超过20
        if sum(count > 20 for count in categorical_value_counts) >= 2:
            plot_types = ['scatter', 'line']
        
        elif 'numeric' in self.column_types and self.column_types.count('numeric') >= 2:
            plot_types.append('line')
        elif self.df.shape[1] > 2 or ('datetime' in self.column_types and type_count['numeric'] == 1):
            plot_types = self.rules['column{}'.format(self.df.shape[1])]['categorical{}'.format(type_count['categorical'])]

        print('plot_types: ', plot_types)
        
        plot_id = 0
        json_list = []
        
        for plot_type in plot_types:
            if plot_type == 'scatter':
                json_list, plot_id = self.scatter_plot(json_list.copy(), plot_id)

            if plot_type == 'line':
                # For line charts
                json_list, plot_id = self.line_chart(json_list.copy(), plot_id)
            
            if plot_type == 'bar':
                json_list, plot_id = self.bar_chart(json_list.copy(), plot_id)

            if plot_type == 'pie':
                json_list, plot_id = self.pie_chart(json_list.copy(), plot_id)

        json_str = json.dumps(json_list, indent=4)
        print(json_str)  # Print the value of json_str
        return json_str  # Return the value of json_str
            