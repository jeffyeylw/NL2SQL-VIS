# from flask_sqlalchemy import SQLAlchemy


from flask import Flask, request
from flask_cors import CORS


app = Flask(__name__)
CORS(app)  # 允许所有来源的跨域请求

@app.route('/input', methods=['GET'])  
def search():
    input_text = request.args.get('query', '')  
    return input_text

# from sql2visual import Data2Visual, sql2data,execute_and_print_query,generate_response

# @app.route('/receive_data', methods=['POST'])

# def send_data():
#     data = request.get_json()  # 从请求中获取 JSON 数据
#     input_text = data.get('input_text', '')  # 从 JSON 数据中获取 input_text

#     # 调用 generate_response 函数来生成响应
#     output1, output2 = generate_response(input_text, target_db_path)

#     # 调用 execute_and_print_query 函数执行 SQL 查询，结果为 JSON 格式
#     query_result = execute_and_print_query(output2, target_db_path)

#     # 执行 SQL 查询并获取结果
#     rows, column_names, column_types = sql2data(sql_command, target_db)

#     data2visual = Data2Visual(img_outputpath, json_outputpath)
#     data2visual.load_data(rows, column_names, column_types)

#     # 执行 plot 方法并获取结果
#     plot_info = data2visual.plot()
#     return plot_info

from sql2visual import Data2Visual, sql2data

@app.route('/receive_data', methods=['POST'])
def send_data():
    target_db = '/Users/frankye/Desktop/BI_Project/financial/financial.sqlite'  # 目标查询数据库
    json_outputpath = "/Users/frankye/Desktop/BI_Project/demo/test/AutoVisual_Results/test1.json"  # 存放绘图数据的.json文件
    img_outputpath = "/Users/frankye/Desktop/BI_Project/demo/test/AutoVisual_Results/test1"  # 存放数据可视化结果图片的文件夹

    sql_command = "select type,bank from trans"

    # 执行 SQL 查询并获取结果
    rows, column_names, column_types = sql2data(sql_command, target_db)

    data2visual = Data2Visual(img_outputpath, json_outputpath)
    data2visual.load_data(rows, column_names, column_types)

    # 执行 plot 方法并获取结果
    plot_info = data2visual.plot()
    return plot_info

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9999)