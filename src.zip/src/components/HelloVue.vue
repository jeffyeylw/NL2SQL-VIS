<template>
  <div>
    <h1>{{ message }}</h1>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      message: 'Loading...'
    };
  },
  async mounted() {
    try {
      const response = await axios.get('/hello_vue');
      this.message = response.data;
    } catch (error) {
      this.message = 'Error loading data';
      console.error(error);
    }
  }
};
</script>