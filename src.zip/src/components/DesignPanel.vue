<template>
  <div class="design-panel">

    <div class="upper-section">
      <h2>🐰 Design Panel</h2>
      <hr>
    </div>
    
    <div class="lower-section">

      <div class="chart-section">
        <div class="content-section">

          <div class="chart-header">
            <hr class="line"/>
            <span class="little-title">CHART</span>
            <hr class="line"/>
          </div>
          
          <div class="chart-accordion">
            <button class="accordion-button" @click="toggleCanvas">
              <i class="icon" :class="{ 'icon-expanded': isCanvasExpanded }">🥝 Canvas</i>
            </button>
            <div class="canvas-content" v-show="isCanvasExpanded">
              <!-- Canvas Content here -->
            </div>
          </div>

        </div>

      </div>

      <div class="overlay-tools">
        <div class="content-section">

          <div class="chart-header">
            <hr class="line"/>
            <span class="little-title">OVERLAY</span>
            <hr class="line"/>
          </div>

          <div class="chart-accordion">
            <button class="accordion-button" @click="toggleCanvas">
              <i class="icon" :class="{ 'icon-expanded': isCanvasExpanded }">🐕 Highlight</i>
            </button>
            <button class="accordion-button" @click="toggleCanvas">
              <i class="icon" :class="{ 'icon-expanded': isCanvasExpanded }">🚕 Background</i>
            </button>
            <button class="accordion-button" @click="toggleCanvas">
              <i class="icon" :class="{ 'icon-expanded': isCanvasExpanded }">🐕 Label</i>
            </button>
            <button class="accordion-button" @click="toggleCanvas">
              <i class="icon" :class="{ 'icon-expanded': isCanvasExpanded }">🚕 Description</i>
            </button>
            <button class="accordion-button" @click="toggleCanvas">
              <i class="icon" :class="{ 'icon-expanded': isCanvasExpanded }">🐕 Trend-Line</i>
            </button>
            <button class="accordion-button" @click="toggleCanvas">
              <i class="icon" :class="{ 'icon-expanded': isCanvasExpanded }">🚕 Overall-indicator</i>
            </button>
          </div>
          
        </div>
        
      </div>
      
    </div>
  </div>
</template>

<script>
export default {
  name: 'DesignPanel',
  data() {
    return {
      isCanvasExpanded: false, // 或者true，取决于你预期的默认行为
      tools: {
        highlight: false,
        markers: false,
        labels: false,
      },
    };
  },
};
</script>

<style scoped>



.design-panel {
  display: flex;
  flex-direction: column;
  /* align-items: center; */
  height: 1000px;
  font-family: Arial, sans-serif;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
  margin: 20px;
  padding: 20px;
  /* width: 100%; */
}

.upper-section {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.upper-section h2 {
  /* box-shadow: 0 0px 3px 0px rgba(0,0,0,0.1); */
  flex-grow: 1;
  margin: 0;
  font-weight: bold;
  font-size: 35px;
}

.lower-section {
  flex-grow: 1;
  width: 100%;
}

hr {
  border: 0;
  height: 1px;
  background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));
}

.chart-header {
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 20px 0;
  width: 100%;
}

.line {
  flex-grow: 1;
  border: none;
  height: 2px;
  background-color: #000;
  margin: 0 10px;
}

.little-title {
  white-space: nowrap;
  padding: 0 10px;
  font-weight: bold;
  font-size: 25px;
}

.chart-accordion .accordion-button {
  font-size: 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 10px;
  text-align: left;
  border: none;
  background-color: #fff;
  cursor: pointer;
  border-bottom: 1px solid #ddd;
}

.chart-accordion .accordion-button .icon {
  transition: transform 0.3s ease;
}

.chart-accordion .accordion-button .icon-expanded {
  transform: rotate(90deg);
}
</style>