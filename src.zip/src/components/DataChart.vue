<template>
  <div class="data-chart-component">
    <div class="chart-header">
      <h2>🏠 Data Chart</h2>
    </div>

    <div v-if="excelData && excelData.length > 0" v-for="(data, index) in excelData" :key="index" :ref="`chart${index}`" :style="{ height: '900px' }"></div>

    <div v-else ref="defaultChart" style="height: 900px;">
      <!-- No data uploaded. Showing default chart. -->
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import * as ecStat from 'echarts-stat';
import axios from 'axios';

export default {
  name: 'DataChart',

  data() {
    return {
      excelData: [],
    };
  },

  watch: {
    excelData: {
      immediate: true,
      handler(newValue) {
        this.$nextTick(() => {
          if (newValue && newValue.length > 0) {
            this.processData();
          }
        });
      },
    },
  },

  mounted() {
    this.$store.watch(
      (state) => state.outputParams,
      () => {
        this.fetchData();
      }
    );
  },
  methods: {
    fetchData() {
      const outputParams = this.$store.state.outputParams;
      console.log('Data received from store:', outputParams);
      this.excelData = outputParams;
    },

    processData() {
      this.excelData.forEach((chartData, index) => {
        const categories = Object.values(chartData)[0];
        const seriesData = [
          {
            name: Object.keys(chartData)[1],
            type: chartData['plot_type'],
            data: Object.values(chartData)[1],
          },
        ];

        this.initChart(categories, seriesData, chartData['plot_type'], index);
      });
    },

    initChart(categories, seriesData, chartType, index) {
      var chartDom = this.$refs[`chart${index}`][0];

      if (!chartDom) {
        console.error(`Chart DOM element not found for index ${index}.`);
        return;
      }

      var myChart = echarts.init(chartDom);

      if (chartType === 'scatter') {
        echarts.registerTransform(ecStat.transform.clustering);

        const data = categories.map((category, index) => [
          category,
          seriesData[0].data[index],
        ]);
        const CLUSTER_COUNT = 6;
        const DIENSIION_CLUSTER_INDEX = 2;
        const COLOR_ALL = [
          '#37A2DA',
          '#e06343',
          '#37a354',
          '#b55dba',
          '#b5bd48',
          '#8378EA',
          '#96BFFF',
        ];
        const pieces = [];

        for (let i = 0; i < CLUSTER_COUNT; i++) {
          pieces.push({
            value: i,
            label: 'cluster ' + i,
            color: COLOR_ALL[i],
          });
        }

        var option = {
          dataset: [
            {
              source: data,
            },
            {
              transform: {
                type: 'ecStat:clustering',
                config: {
                  clusterCount: CLUSTER_COUNT,
                  outputType: 'single',
                  outputClusterIndexDimension: DIENSIION_CLUSTER_INDEX,
                },
              },
            },
          ],
          tooltip: {
            position: 'top',
          },
          visualMap: {
            type: 'piecewise',
            top: 'middle',
            min: 0,
            max: CLUSTER_COUNT,
            left: 10,
            splitNumber: CLUSTER_COUNT,
            dimension: DIENSIION_CLUSTER_INDEX,
            pieces: pieces,
          },
          grid: {
            left: 120,
          },
          xAxis: {},
          yAxis: {},
          series: {
            type: 'scatter',
            encode: { tooltip: [0, 1] },
            symbolSize: 15,
            itemStyle: {
              borderColor: '#555',
            },
            datasetIndex: 1,
          },
        };

        myChart.setOption(option, true);
      } else {
        var option = {
          tooltip: {},
          legend: {
            data: seriesData.map((item) => item.name),
          },
          xAxis: {
            type: 'category',
            data: categories,
          },
          yAxis: {
            type: 'value',
          },
          series: seriesData.map((series) => {
            return {
              ...series,
              type: chartType,
            };
          }),
        };

        if (chartType === 'pie') {
          option.series.forEach((series) => {
            series.type = 'pie';
          });
        }

        myChart.setOption(option, true);
      }

      window.addEventListener('resize', () => {
        myChart.resize();
      });
    },
  },
};
</script>

<style scoped>
.data-chart-component {
  font-family: Arial, sans-serif;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
  margin: 20px;
  padding: 20px;
}

.chart-header {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.chart-header h2 {
  flex-grow: 1;
  margin: 0;
  font-weight: bold;
  font-size: 35px;
}
</style>
