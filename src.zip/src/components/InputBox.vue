<template>
  <div class="input-box">
    <h2 class="input-box-header">Search</h2> <!-- 添加标题 -->
    <div class="message-input">
      <input type="text" placeholder="Please input your request" v-model="message" />
      <button class="send-button" @click="sendMessage">➤</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'InputBox',
  data() {
    return {
      message: ''
    };
  },
  methods: {
    async sendMessage() {
      try {
        const response = await axios.get(`http://10.120.18.241:32286/input?query=${encodeURIComponent(this.message)}`);
        console.log('GET request successful');
        const outputParams = response.data;
        this.$store.commit('setOutputParams', outputParams);

        // Call fetchData in datachart component to update the excelData
        this.$root.$emit('fetchData');
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    }
  }  
};
</script>

<style scoped>
.input-box {
  font-family: Arial, sans-serif;
  margin: 20px;
  padding: 20px;
  display: flex;
  flex-direction: column;
}

.input-box-header {
  margin-bottom: 10px; /* 添加标题的样式 */
}

.message-input {
  display: flex;
  border: 3px solid #333; /* 更改边框颜色和宽度 */
  border-radius: 4px;
}

.message-input input {
  flex-grow: 1;
  border: none;
  padding: 10px; /* 增加内边距以增大输入框 */
  font-size: 1.2em; /* 增大字体大小 */
}

.message-input .send-button {
  background: #eee;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
}
</style>