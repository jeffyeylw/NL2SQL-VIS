<template>
  <div class="data-table-component">

    <div class="table-header">
      <h2>🍉 Data Table</h2>
    </div>

    <div class="table-container">
     
      <div v-if="excelData" class="excel-data-container">
        <table>
          <!-- 表格的行(tr)和单元格(td)通过循环excelData数组生成 -->
          <tr v-for="(row, index) in excelData" :key="index">
            <td v-for="(cell, key) in row" :key="key">{{ cell }}</td>
          </tr>
        </table>
      </div>
      <div v-else>
        <thead>
          <tr>
            <th>id</th>
            <th>time</th>
            <th>installed winenergy</th>     
            <th>sales</th>

          </tr>
        </thead>
        <tbody>
          <tr v-for="entry in dataEntries" :key="entry.id">
            <td>{{ entry.id }}</td>
            <td>{{ entry.time }}</td>
            <td>{{ entry.winenergy }}</td>
            <td>{{ entry.sales }}</td> 
          </tr>
        </tbody>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: 'DataTable',
  props: ['excelData'],
  data() {
    return {
      // Example dataset
      dataEntries: Array.from({ length: 15 }, (_, index) => ({
        id: index + 1,
        time: 2000 + index,
        winenergy: (850 + index * 10).toString() + ' kWh',
        sales: 1022,
      })),
    };
  },
};
</script>

<style scoped>
.data-table-component {
  font-family: Arial, sans-serif;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
  margin: 20px;
  padding: 20px;
  /* 确保组件本身不会超过其父容器的宽度 */
  max-width: 100%;
}

.table-header h2 {
  margin: 0 0 10px 0;
  font-weight: bold;
  font-size: 35px;
  flex-grow: 1;
}

.table-container {
  max-height: 400px; /* 举例，你可以根据实际情况调整这个值 */
  /* max-width: 100%; 使得容器宽度不超过其父元素 */
  overflow-y: auto;
  /* overflow-x: auto; */
  border: 1px solid #ddd;
  /* width: 100%; */
  /* border-collapse: collapse; */
}

.excel-data-container {
  overflow-x: auto; /* 启用水平滚动 */
}

.table-container table {
  /* 让表格根据内容自动扩展宽度 */
  width: 400px;
   /* 确保表格至少有容器的宽度，但可以根据内容扩展 */
  /* min-width: 100%; */
  border-collapse: collapse;
}

.table-container thead {
  background-color: #f9f9f9;
  position: sticky;
  top: 0; /* Keep the header on top while scrolling */
}

.table-container th, .table-container td {
  padding: 10px;
  border-bottom: 1px solid #ddd;
  white-space: nowrap; /* 防止内容换行，更易触发水平滚动 */
  font-size: 20px;
  text-align: center;
}
</style>
