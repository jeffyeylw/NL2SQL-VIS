<template>
  <div class="narrative-panel">
    
    <div class="panel-header">
      <h2>🌳 Narrative Panel</h2>
      <div class="toolbar">
        <!-- Insert toolbar icons here -->
      </div>
    </div>
    
    <div class="segmented-control">
      <button class="control-button active">Subject</button>
      <button class="control-button">Numerical</button>
      <button class="control-button">Trend</button>
    </div>
    <div class="content-area">
      <!-- Spinner shown here for loading state -->
      <div class="spinner"></div>
    </div>
    <div class="reason-section">
      <label for="reason">🐯 Reason:</label>
      <textarea id="reason" rows="4" placeholder="Explain the reason here..."></textarea>
    </div>
    <div class="message-input">
      <input type="text" placeholder="Send a message" />
      <button class="send-button">➤</button>
    </div>
  </div>
</template>



<script>
export default {
  name: 'NarrativePanel',
  // Script content...
};
</script>



<style scoped>

.narrative-panel {
  /* max-width: 400px; */
  /* border: 1px solid #ddd; */
  height: 480px;
  font-family: Arial, sans-serif;
  margin: 20px;
  padding: 20px;
  /* border-radius: 4px; */
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);

  display: flex;
  flex-direction: column;
}

.panel-header {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.panel-header h2 {
  flex-grow: 1;
  margin: 0;
  font-weight: bold;
  font-size: 35px;
}


.segmented-control {
  display: flex;
  justify-content: space-around;
  margin-bottom: 10px;
}

.control-button {
  font-size: 15px;
  padding: 5px 10px;
  border: 1px solid #ddd;
  background-color: #fff;
  border-radius: 4px;
  cursor: pointer;
}

.control-button.active {
  background-color: #eee;
}

.content-area {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 10px;
  margin-bottom: 10px;
  position: relative;
  min-height: 100px; /* Adjust based on content */
}


.reason-section {
  margin-bottom: 10px;
  font-size: 20px;
}

.reason-section textarea {
  width: 100%;
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
}

.message-input {
  display: flex;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.message-input input {
  flex-grow: 1;
  border: none;
  padding: 5px;
}

.message-input .send-button {
  background: #eee;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
}
</style>
