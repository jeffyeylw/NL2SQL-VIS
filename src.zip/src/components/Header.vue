<template>
  <div class="header">
    <div class="title-section">
      <span class="title">🛠️ DataArts Insight</span>
    </div>

    <div class="button-section">

      <!-- 一个文件输入(input)元素，用于上传文件 -->
      <!-- 隐藏的文件上传控件 -->
      <input type="file" @change="handleFileUpload" ref="fileInput" style="display: none;"/>
      <!-- 可见的按钮，点击时触发文件上传控件 --> 
      <button class="header-button" @click="triggerFileInput">⬆️ Input</button>
      <button class="header-button" @click="exportData">⬇️ Export</button>
    </div>
  </div>
</template>

<script>
// 引入了xlsx库，该库用于处理Excel文件
import * as XLSX from 'xlsx';

export default {
  name: 'HeaderPanel',
  data() {
    return {
      excelData: null
    };
  },
  methods: {
    handleFileUpload(event) {
      // 事件处理函数，用于处理文件上传输入的变化。当用户选择文件后，此方法会被触发
      const file = event.target.files[0]; //获取到选中的文件
      //用FileReader对象来读取文件内容。
      // FileReader以二进制格式(binary)读取文件，这对于xlsx库处理Excel文件是必要的
      const reader = new FileReader();
      //当文件读取完成后（reader.onload事件触发）
      reader.onload = (e) => {
        const data = e.target.result;
        //使用xlsx.read方法读取文件数据，创建一个workbook（工作簿）对象
        //这个对象包含了Excel文件中的所有数据。
        const workbook = XLSX.read(data, { type: 'binary' });
        //从工作簿中获取第一个工作表的名称（workbook.SheetNames[0]），并使用它来获取对应的工作表对象
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        // XLSX.utils.sheet_to_json方法将工作表数据转换为JSON格式
        // 转换后的数据被赋值给excelData属性，用于在模板中渲染表格。
        this.excelData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        // 假设excelData是处理后的数据，将这个属性发送给父组件
        this.$emit('file-loaded', this.excelData); 
      };
      reader.readAsBinaryString(file);  //文件读取
      
    },
    triggerFileInput() {
      // 触发file input的点击事件
      this.$refs.fileInput.click();
    },
    importData() {
      // Logic for importing data
    },
    exportData() {
      // Logic for exporting data
    }
  }
};

</script>

<style scoped>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #333;
  color: white;
  /* width: 100%; */
}

.title-section .title {
  font-size: 45px;
  font-weight: bold;
}

.button-section {
  display: flex; /* This ensures that the buttons are placed side by side */
}

.header-button {
  padding: 5px 10px;
  margin-left: 5px; /* This separates the buttons from each other */
  border: none;
  border-radius: 5px;
  background-color: #555;
  color: white;
  font-size: 30px;
  cursor: pointer;
  display: flex; /* Aligns the icon and text within the button */
  align-items: center; /* Centers the icon and text vertically */
}

.header-button:hover {
  background-color: #666;
}
</style>
