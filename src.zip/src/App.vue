<template>
  <div class="container">
    <HeaderPanel @file-loaded="handleFileLoaded" />
    <div class="content">
      <div class="column">
        <DataTable :excelData="excelData"/>
        <InputBox />
        <NarrativePanel />
      </div>
      <div class="column">
        <DataChart :excelData="excelData"/>
        <HelloVue />
      </div>
      <div class="column">
        <DesignPanel />
      </div>
    </div>
  </div>
</template>

<script>
import HeaderPanel from './components/Header.vue';
import DataTable from './components/DataTable.vue';
import DataChart from './components/DataChart.vue';
import DesignPanel from './components/DesignPanel.vue';
import NarrativePanel from './components/NarrativePanel.vue';
import InputBox from './components/InputBox.vue';
import HelloVue from './components/HelloVue.vue'; // Import the HelloVue component

export default {
  data() {
    return {
      excelData: [],
    };
  },
  components: {
    HeaderPanel,
    DataTable,
    DataChart,
    DesignPanel,
    NarrativePanel,
    InputBox,
    HelloVue // Include the HelloVue component
  },
  methods: {
    handleFileLoaded(data) {
      this.excelData = data;
    }
  }
};
</script>


<style>
#app {
  height: 100%;
  width: 100%;
}


.container {
  padding: 0.125rem 0.125rem 0;
  display: flex;
  flex-direction: column;
  .column {
    flex: 3;
  }
  &:nth-child(2) {
    flex: 5;
  }

  .content {
    display: flex;
    min-width: 1900px;
    max-width: 1920px;
    margin: 0 auto;
    padding: 0.125rem 0.125rem 0;
  }
  .content .column {
    flex: 3;
  }
  .content .column:nth-child(2) {
    flex: 5;
    margin: 0 0.125rem 0.1875rem;
    overflow: hidden;
  }
}

</style>
