import './assets/main.css'
import { createApp } from 'vue'
import App from './App.vue'
import store from '../store/store.js'  // 如果你把store.js放在了store文件夹中，这里应该改为 './store/store.js'

createApp(App)
  .use(store)  // 使用store
  .mount('#app')